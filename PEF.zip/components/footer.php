  </div>
  </div>
  <footer class="page-footer font-small darken-3">
    <div class="footer-copyright py-3">
      <div class="center">
        © 2020 Copyright:
        <a href="https://www.pef.jus.br"> P.E.F.</a><!-- Facebook -->
        <a class="fb-ic">
          <i class="fa fa-facebook-f fa-lg white-text ml-3 mr-3 fa-2x"> </i>
        </a>
        <!-- Twitter -->
        <a class="tw-ic">
          <i class="fa fa-twitter fa-lg white-text ml-3 mr-3 fa-2x"> </i>
        </a>
        <!--Instagram-->
        <a class="ins-ic">
          <i class="fa fa-instagram fa-lg white-text ml-3 mr-3 fa-2x"> </i>
        </a>
      </div>
    </div>

  </footer>