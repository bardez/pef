<?php
    define('HOST', '127.0.0.1');
    define('DATABASE', 'pef');
    define('USER', 'root');
    define('PASSWORD', 'bardez');
    define('PORT', '3306');

    define('DEFAULT_URL', 'http://localhost:5000/');
?>