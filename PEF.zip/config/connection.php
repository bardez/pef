<?php
    require_once('constants.php');
    $connection = mysqli_connect(HOST, USER, PASSWORD, DATABASE, PORT);
?>
